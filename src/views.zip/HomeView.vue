<template>
  <div class="home">
    <header class="home-header">
      <div class="header-left">
        <IconHeart :size="20" :filled="true" class="logo-icon" />
        <h1>memories</h1>
      </div>
      <div class="header-right">
        <select v-if="groupsStore.groups.length > 1" v-model="selectedGroupId" class="group-select" @change="onGroupChange">
          <option v-for="g in groupsStore.groups" :key="g.id" :value="g.id">{{ g.name }}</option>
        </select>
        <span v-else-if="groupsStore.currentGroup" class="group-name">{{ groupsStore.currentGroup.name }}</span>
      </div>
    </header>

    <div v-if="!groupsStore.currentGroup && !groupsStore.loading" class="empty-state">
      <IconHeart :size="48" />
      <p>Ще немає групи</p>
      <button class="btn-accent" @click="showCreateGroup = true">Створити групу</button>
    </div>

    <div v-else>
      <div class="create-day-bar">
        <button class="create-day-btn" @click="showCreateDay = true">
          <IconPlus :size="18" />
          <span>Новий день</span>
        </button>
      </div>

      <div v-if="loading && days.length === 0" class="loader-wrap">
        <div class="loader"></div>
      </div>

      <div v-else-if="days.length === 0" class="empty-state">
        <IconCalendar :size="48" />
        <p>Поки немає спогадів</p>
        <button class="btn-accent" @click="showCreateDay = true">Додати перший день</button>
      </div>

      <div v-else class="days-list">
        <DayCard
            v-for="day in days"
            :key="day.id"
            :day="day"
            @click="goToDay(day.id)"
            @delete="deleteDay(day.id)"
        />
        <div v-if="hasMore" class="load-more">
          <button class="btn-ghost" @click="loadMore" :disabled="loading">
            {{ loading ? '...' : 'Завантажити ще' }}
          </button>
        </div>
      </div>
    </div>

    <transition name="slide-up">
      <div v-if="showCreateDay" class="modal-overlay" @click.self="showCreateDay = false">
        <div class="modal">
          <div class="modal-header">
            <h2>Новий день</h2>
            <button @click="showCreateDay = false"><IconClose :size="20" /></button>
          </div>
          <div class="modal-body">
            <div class="field">
              <label>Дата</label>
              <input v-model="newDayDate" type="date" class="input" />
            </div>
          </div>
          <div class="modal-footer">
            <button class="btn-accent" @click="createDay" :disabled="!newDayDate || createLoading">
              {{ createLoading ? '...' : 'Створити' }}
            </button>
          </div>
        </div>
      </div>
    </transition>

    <transition name="slide-up">
      <div v-if="showCreateGroup" class="modal-overlay" @click.self="showCreateGroup = false">
        <div class="modal">
          <div class="modal-header">
            <h2>Нова група</h2>
            <button @click="showCreateGroup = false"><IconClose :size="20" /></button>
          </div>
          <div class="modal-body">
            <div class="field">
              <label>Назва групи</label>
              <input v-model="newGroupName" type="text" class="input" placeholder="Назва" />
            </div>
            <div class="field">
              <label>Партнер</label>
              <div class="search-wrap">
                <input
                    v-model="userQuery"
                    type="text"
                    class="input"
                    placeholder="Пошук за іменем або email"
                    @input="onUserSearch"
                />
                <div v-if="userResults.length" class="search-dropdown">
                  <button
                      v-for="u in userResults"
                      :key="u.id"
                      class="search-option"
                      @click="selectPartner(u)"
                  >
                    <div class="user-avatar-sm">{{ u.fullName?.charAt(0) || u.username?.charAt(0) }}</div>
                    <div class="user-option-info">
                      <span class="user-option-name">{{ u.fullName }}</span>
                      <span class="user-option-sub">@{{ u.username }}</span>
                    </div>
                  </button>
                </div>
              </div>
              <div v-if="selectedPartner" class="selected-partner">
                <div class="user-avatar-sm">{{ selectedPartner.fullName?.charAt(0) }}</div>
                <div class="user-option-info">
                  <span class="user-option-name">{{ selectedPartner.fullName }}</span>
                  <span class="user-option-sub">@{{ selectedPartner.username }}</span>
                </div>
                <button class="remove-partner" @click="selectedPartner = null; userQuery = ''">
                  <IconClose :size="14" />
                </button>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button class="btn-accent" @click="createGroup" :disabled="!newGroupName || !selectedPartner || createLoading">
              {{ createLoading ? '...' : 'Створити' }}
            </button>
          </div>
        </div>
      </div>
    </transition>
  </div>
</template>

<script setup>
import { ref, onMounted, watch } from 'vue'
import { useRouter } from 'vue-router'
import { useGroupsStore } from '../stores/group.js'
import { memoriesApi } from '../api/memories.js'
import { groupsApi } from '../api/group.js'
import DayCard from '../components/DayCard.vue'
import IconHeart from '../components/icons/IconHeart.vue'
import IconPlus from '../components/icons/IconPlus.vue'
import IconClose from '../components/icons/IconClose.vue'
import IconCalendar from '../components/icons/IconCalendar.vue'

const router = useRouter()
const groupsStore = useGroupsStore()

const days = ref([])
const loading = ref(false)
const page = ref(0)
const hasMore = ref(true)
const showCreateDay = ref(false)
const showCreateGroup = ref(false)
const newDayDate = ref(new Date().toISOString().split('T')[0])
const newGroupName = ref('')
const createLoading = ref(false)
const selectedGroupId = ref(null)

const userQuery = ref('')
const userResults = ref([])
const selectedPartner = ref(null)
let searchTimeout = null

onMounted(async () => {
  await groupsStore.fetchMyGroups()
  if (groupsStore.currentGroup) {
    selectedGroupId.value = groupsStore.currentGroup.id
    await loadDays()
  }
})

watch(() => groupsStore.currentGroup, async (g) => {
  if (g) {
    selectedGroupId.value = g.id
    days.value = []
    page.value = 0
    hasMore.value = true
    await loadDays()
  }
})

const onGroupChange = async () => {
  await groupsStore.fetchGroupById(selectedGroupId.value)
  days.value = []
  page.value = 0
  hasMore.value = true
  await loadDays()
}

const loadDays = async () => {
  if (!groupsStore.currentGroup || loading.value) return
  loading.value = true
  try {
    const result = await memoriesApi.getGroupDays(groupsStore.currentGroup.id, page.value, 10)
    const items = Array.isArray(result) ? result : result.content || []
    days.value.push(...items)
    hasMore.value = items.length === 10
  } finally {
    loading.value = false
  }
}

const loadMore = async () => {
  page.value++
  await loadDays()
}

const goToDay = (id) => {
  router.push({ name: 'day', params: { id } })
}

const deleteDay = async (id) => {
  await memoriesApi.deleteDay(id)
  days.value = days.value.filter(d => d.id !== id)
}

const createDay = async () => {
  if (!newDayDate.value || !groupsStore.currentGroup) return
  createLoading.value = true
  try {
    const day = await memoriesApi.createDay({
      groupId: groupsStore.currentGroup.id,
      date: newDayDate.value
    })
    days.value.unshift(day)
    showCreateDay.value = false
    router.push({ name: 'day', params: { id: day.id } })
  } finally {
    createLoading.value = false
  }
}

const onUserSearch = () => {
  clearTimeout(searchTimeout)
  if (!userQuery.value.trim() || selectedPartner.value) {
    userResults.value = []
    return
  }
  searchTimeout = setTimeout(async () => {
    try {
      userResults.value = await groupsApi.searchUsers(userQuery.value.trim())
    } catch {
      userResults.value = []
    }
  }, 300)
}

const selectPartner = (u) => {
  selectedPartner.value = u
  userQuery.value = ''
  userResults.value = []
}

const createGroup = async () => {
  if (!newGroupName.value || !selectedPartner.value) return
  createLoading.value = true
  try {
    await groupsStore.createGroup({
      name: newGroupName.value,
      memberIds: [selectedPartner.value.id]
    })
    showCreateGroup.value = false
    newGroupName.value = ''
    selectedPartner.value = null
    userQuery.value = ''
    days.value = []
    page.value = 0
    await loadDays()
  } finally {
    createLoading.value = false
  }
}
</script>

<style scoped>
.home {
  padding: 0 0 16px;
}

.home-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 16px 20px 12px;
  position: sticky;
  top: 0;
  background: var(--bg);
  z-index: 10;
  border-bottom: 1px solid var(--border);
}

.header-left {
  display: flex;
  align-items: center;
  gap: 8px;
}

.logo-icon {
  color: var(--accent);
}

.home-header h1 {
  font-size: 18px;
  font-weight: 700;
  letter-spacing: -0.3px;
}

.group-select {
  background: var(--input-bg);
  border: 1px solid var(--border);
  border-radius: 10px;
  padding: 6px 10px;
  font-size: 13px;
  color: var(--text);
  max-width: 140px;
}

.group-name {
  font-size: 13px;
  color: var(--text-muted);
  font-weight: 500;
}

.create-day-bar {
  padding: 14px 20px 8px;
}

.create-day-btn {
  display: flex;
  align-items: center;
  gap: 8px;
  background: var(--accent-light);
  color: var(--accent);
  border-radius: 14px;
  padding: 11px 18px;
  font-size: 14px;
  font-weight: 600;
  width: 100%;
  justify-content: center;
  transition: opacity 0.2s;
}

.create-day-btn:hover {
  opacity: 0.8;
}

.days-list {
  padding: 8px 20px;
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 14px;
  padding: 60px 20px;
  color: var(--text-muted);
}

.empty-state p {
  font-size: 15px;
}

.loader-wrap {
  display: flex;
  justify-content: center;
  padding: 40px;
}

.loader {
  width: 32px;
  height: 32px;
  border: 3px solid var(--border);
  border-top-color: var(--accent);
  border-radius: 50%;
  animation: spin 0.7s linear infinite;
}

@keyframes spin {
  to { transform: rotate(360deg); }
}

.load-more {
  display: flex;
  justify-content: center;
  padding: 8px 0;
}

.btn-accent {
  background: var(--accent);
  color: white;
  border-radius: 12px;
  padding: 11px 22px;
  font-size: 14px;
  font-weight: 600;
  transition: background 0.2s;
}

.btn-accent:hover:not(:disabled) {
  background: var(--accent-hover);
}

.btn-accent:disabled {
  opacity: 0.6;
}

.btn-ghost {
  color: var(--accent);
  font-size: 14px;
  font-weight: 500;
  padding: 8px 16px;
}

.modal-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,0.4);
  display: flex;
  align-items: flex-end;
  justify-content: center;
  z-index: 200;
  backdrop-filter: blur(2px);
}

.modal {
  background: var(--bg-card);
  border-radius: 24px 24px 0 0;
  width: 100%;
  max-width: 480px;
  padding: 24px 24px calc(24px + env(safe-area-inset-bottom));
}

.modal-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 20px;
}

.modal-header h2 {
  font-size: 17px;
  font-weight: 700;
}

.modal-header button {
  color: var(--text-muted);
  display: flex;
  align-items: center;
}

.modal-body {
  display: flex;
  flex-direction: column;
  gap: 14px;
}

.modal-footer {
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
}

.field {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.field label {
  font-size: 13px;
  font-weight: 500;
  color: var(--text-muted);
}

.input {
  background: var(--input-bg);
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 11px 14px;
  font-size: 15px;
  color: var(--text);
  width: 100%;
  transition: border-color 0.2s;
}

.input:focus {
  border-color: var(--accent);
}

.search-wrap {
  position: relative;
}

.search-dropdown {
  position: absolute;
  top: calc(100% + 4px);
  left: 0;
  right: 0;
  background: var(--bg-card);
  border: 1px solid var(--border);
  border-radius: 12px;
  box-shadow: 0 8px 24px var(--shadow);
  z-index: 50;
  max-height: 200px;
  overflow-y: auto;
}

.search-option {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 14px;
  width: 100%;
  text-align: left;
  transition: background 0.15s;
}

.search-option:hover {
  background: var(--bg-secondary);
}

.user-avatar-sm {
  width: 32px;
  height: 32px;
  border-radius: 50%;
  background: var(--accent-light);
  color: var(--accent);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 13px;
  font-weight: 700;
  flex-shrink: 0;
  text-transform: uppercase;
}

.user-option-info {
  display: flex;
  flex-direction: column;
  gap: 1px;
}

.user-option-name {
  font-size: 14px;
  font-weight: 600;
  color: var(--text);
}

.user-option-sub {
  font-size: 12px;
  color: var(--text-muted);
}

.selected-partner {
  display: flex;
  align-items: center;
  gap: 10px;
  background: var(--accent-light);
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 10px 12px;
  margin-top: 6px;
}

.remove-partner {
  margin-left: auto;
  color: var(--text-muted);
  display: flex;
  align-items: center;
  padding: 2px;
}

.remove-partner:hover {
  color: #e05555;
}
</style>