<template>
  <div :class="currentTheme" class="app">
    <router-view />
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { useThemeStore } from './stores/theme'

const themeStore = useThemeStore()
const currentTheme = computed(() => themeStore.theme)
</script>

<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
}

.app {
  min-height: 100vh;
  transition: background-color 0.3s, color 0.3s;
}

.white {
  --bg-primary: #ffffff;
  --bg-secondary: #f5f5f5;
  --bg-card: #ffffff;
  --text-primary: #1a1a1a;
  --text-secondary: #666666;
  --border: #e0e0e0;
  --accent: #ff6b9d;
  --accent-hover: #ff4d88;
  --shadow: rgba(0, 0, 0, 0.1);
}

.pastel {
  --bg-primary: #fff0f5;
  --bg-secondary: #ffe4ec;
  --bg-card: #ffffff;
  --text-primary: #4a4a4a;
  --text-secondary: #8b8b8b;
  --border: #ffc9d9;
  --accent: #ff85a8;
  --accent-hover: #ff6b9d;
  --shadow: rgba(255, 107, 157, 0.15);
}

.dark {
  --bg-primary: #1a1a1a;
  --bg-secondary: #2d2d2d;
  --bg-card: #242424;
  --text-primary: #ffffff;
  --text-secondary: #b0b0b0;
  --border: #404040;
  --accent: #ff6b9d;
  --accent-hover: #ff4d88;
  --shadow: rgba(0, 0, 0, 0.5);
}

.dark-pastel {
  --bg-primary: #2d1b2e;
  --bg-secondary: #3d2a3e;
  --bg-card: #33243a;
  --text-primary: #f5e6f0;
  --text-secondary: #c9a8d4;
  --border: #5d4a6e;
  --accent: #d47fa8;
  --accent-hover: #ff85a8;
  --shadow: rgba(212, 127, 168, 0.2);
}

.white,
.pastel,
.dark,
.dark-pastel {
  background-color: var(--bg-primary);
  color: var(--text-primary);
}
</style>