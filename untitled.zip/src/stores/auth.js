import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import { authApi } from '../api/auth.js'

export const useAuthStore = defineStore('auth', () => {
    const token = ref(localStorage.getItem('auth_token') || null)
    const user = ref(JSON.parse(localStorage.getItem('auth_user') || 'null'))

    const isAuthenticated = computed(() => !!token.value)

    const login = async (email, password) => {
        const response = await authApi.login(email, password)
        token.value = response.token
        user.value = response.user
        localStorage.setItem('auth_token', response.token)
        localStorage.setItem('auth_user', JSON.stringify(response.user))
    }

    const register = async (data) => {
        const response = await authApi.register(data)
        token.value = response.token
        user.value = response.user
        localStorage.setItem('auth_token', response.token)
        localStorage.setItem('auth_user', JSON.stringify(response.user))
    }

    const logout = () => {
        token.value = null
        user.value = null
        localStorage.removeItem('auth_token')
        localStorage.removeItem('auth_user')
    }

    return {
        token,
        user,
        isAuthenticated,
        login,
        register,
        logout
    }
})